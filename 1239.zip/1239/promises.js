<html>
    <head><script src ="promises.js"></script>
    </head>
    <body>
    </body>
</html>
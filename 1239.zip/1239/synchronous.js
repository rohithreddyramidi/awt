console.log('ABC');
console.log('123');
setTimeout(()=> {
    console.log('rohith');
},0);
calculate();
console.log('a');
function calculate() 
{ 
    let sum = 0;
    for(let i = 0; i<25; i++){
        sum +=i;
    }
    console.log('sum is :',sum)
 }
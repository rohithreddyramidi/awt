/* console.log('ABC');
setTimeout(()=> {
    console.log('123');
},10000);
console.log('5235');
 */

console.log('ABC');
setTimeout(()=> {
    console.log('123');
},0);
console.log('5235');
calculate();
function calculate()
{ 
    let sum = 0;
    for(let i = 0; i<5; i++){
        sum +=i;
    }
    console.log('sum is :',sum)
 }
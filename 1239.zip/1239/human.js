class User{
    constructor(username,email,password){
        this.username=username;
        this.email=email;
        this.password=password;
    }
    static countusers(){
        console.log('50 users');
    }
    register(){
        console.log(this.username+' is now registered');
    }
}
let details=new User('cvr','cvr@cvr.ac.in','12345667789');
details.register();
User.countusers();
// User.register();                                                                                                   
class Member extends User{
    constructor(username,email,password){
        super(username,email,password);
        
    }
}
const it=new Member('IT_a','itb@cvr',1239);
console.log(details.username);